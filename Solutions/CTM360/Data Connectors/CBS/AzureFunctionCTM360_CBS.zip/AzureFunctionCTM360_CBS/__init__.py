import logging
import hashlib
import hmac
import os
import azure.functions as func
import json
import re
import base64
import requests
import datetime
import traceback
import time
from .state_manager import StateManager

# Environment Variables
cbs_api_key = os.environ.get('api_key')
customer_id = os.environ.get('WorkspaceID')
shared_key = os.environ.get('WorkspaceKey')
logAnalyticsUri = os.environ.get('logAnalyticsUri')
olddate_from = os.environ.get('date_from')   # expected as epoch milliseconds (string)
olddate_to = os.environ.get('date_to')       # expected as epoch milliseconds (string); optional
backupflag = os.environ.get('backupflag')
log_type = 'CBSLog_Azure_1_CL'
MAX_RETRIES = 3
RETRY_INTERVAL_SECONDS = 60
connection_string = os.environ['AzureWebJobsStorage']

# Ensure logAnalyticsUri has a default if empty.
if not logAnalyticsUri or str(logAnalyticsUri).isspace():
    logAnalyticsUri = f'https://{customer_id}.ods.opinsights.azure.com'

pattern = r'https:\/\/([\w\-]+)\.ods\.opinsights\.azure.([a-zA-Z\.]+)$'
match = re.match(pattern, str(logAnalyticsUri))
if not match:
    raise Exception("CBS Data Connector: Invalid Log Analytics Uri.")

# Timezone offset if needed (e.g., UTC+3 => 3*3600). Currently set to 0.
bahrain_timezone_offset = 0

# API base URL (Sentinel endpoint)
base_url = "https://cbs.ctm360.com/api/v2/sentinel"

# Module configurations
module_configs = [
    {"module_type": "incidents", "max_hits": 10000},
    {"module_type": "malware_logs", "max_hits": 10000},
    {"module_type": "breached_credentials", "max_hits": 10000},
    {"module_type": "compromised_cards", "max_hits": 10000},
    {"module_type": "domain_infringement", "max_hits": 10000},
    {"module_type": "subdomain_infringement", "max_hits": 10000}
]

def format_iso8601(timestamp):
    """
    Convert a UNIX timestamp to 'DD-MM-YYYY HH:MM' in UTC.
    Example: 25-10-2024 13:55
    """
    return time.strftime("%d-%m-%Y %H:%M", time.gmtime(timestamp))

def build_signature(customer_id, shared_key, date, content_length, method, content_type, resource):
    """
    Build the authorization signature for Azure Log Analytics.
    """
    x_headers = 'x-ms-date:' + date
    string_to_hash = f"{method}\n{content_length}\n{content_type}\n{x_headers}\n{resource}"
    bytes_to_hash = string_to_hash.encode("utf-8")
    decoded_key = base64.b64decode(shared_key)
    encoded_hash = base64.b64encode(hmac.new(decoded_key, bytes_to_hash, digestmod=hashlib.sha256).digest()).decode()
    authorization = f"SharedKey {customer_id}:{encoded_hash}"
    return authorization

def parse_response_data(response_json):
    """
    For the new API, we expect the returned data to be under the "hits" key.
    """
    if "hits" in response_json:
        return response_json["hits"]
    else:
        return [response_json]

def perform_request(url, headers):
    """
    Execute an HTTP GET request (with retries) to the Sentinel API and,
    on success, send the retrieved records to Azure Sentinel.
    """
    for attempt in range(MAX_RETRIES):
        try:
            response = requests.get(url, headers=headers, timeout=(5, 10))
            response.raise_for_status()  # Raises HTTPError if status is not 2xx/3xx

            if response.status_code == 429:
                logging.warning("HTTP 429 (Too Many Requests). Retrying...")
                time.sleep(RETRY_INTERVAL_SECONDS)
            else:
                message_json = response.json()
                records = parse_response_data(message_json)
                post_data_to_sentinel(json.dumps(records))
                return True

        except requests.exceptions.RequestException as e:
            logging.warning(f"Request failed: {str(e)}")
            if attempt < MAX_RETRIES - 1:
                logging.info(f"Retrying in {RETRY_INTERVAL_SECONDS} seconds...")
                time.sleep(RETRY_INTERVAL_SECONDS)
            else:
                logging.error("Max retries reached. Exiting.")
                return False

def post_data_to_sentinel(body):
    """
    Send the JSON payload to Azure Sentinel (Log Analytics Data Collector API).
    """
    method = 'POST'
    content_type = 'application/json'
    resource = '/api/logs'
    # Use a timezone-aware UTC datetime to avoid deprecation warnings.
    rfc1123date = datetime.datetime.now(datetime.timezone.utc).strftime('%a, %d %b %Y %H:%M:%S GMT')
    content_length = len(body)

    signature = build_signature(customer_id, shared_key, rfc1123date, content_length, method, content_type, resource)

    uri = f"{logAnalyticsUri}{resource}?api-version=2016-04-01"
    headers = {
        'content-type': content_type,
        'Authorization': signature,
        'Log-Type': log_type,
        'x-ms-date': rfc1123date
    }

    try:
        response = requests.post(uri, data=body, headers=headers)
        if 200 <= response.status_code <= 299:
            logging.info("Data successfully sent to Azure Sentinel.")
            return response.status_code
        else:
            logging.error(f"Failed to send data. Response code: {response.status_code}")
            return None
    except Exception:
        logging.error("Exception occurred while posting data to Sentinel:")
        logging.error(traceback.format_exc())
        return None

def main(mytimer: func.TimerRequest) -> None:
    """
    Timer-triggered function entry point.
    Retrieves data from the CyberBlindSpot Sentinel API for each module configuration,
    using a start (date_from) and end (date_to) timestamp (in epoch milliseconds),
    and posts the logs to Azure Sentinel.

    Date Range Logic:
      - If backupflag=="true":
          * If both olddate_from and olddate_to are provided, use them (static window).
          * If only olddate_from is provided, use incremental mode:
            start = olddate_from, end = now, then update stored start to now.
      - Otherwise, use a rolling window (last 5 minutes).
    """
    if mytimer.past_due:
        logging.warning('The timer is past due!')

    current_ms = int(time.time() * 1000)

    # Default: rolling window (last 5 minutes)
    timestamp_from = current_ms - (5 * 60 * 1000)
    timestamp_to = current_ms

    if backupflag == "true":
        state = StateManager(connection_string)
        backup_status = state.get()
        # If an incremental/static backup hasn't been done yet:
        if backup_status in [None, "", "false"]:
            if olddate_from:
                try:
                    timestamp_from = int(olddate_from)
                except (TypeError, ValueError):
                    logging.error("Invalid olddate_from; falling back to rolling window.")
                    timestamp_from = current_ms - (5 * 60 * 1000)
            # If olddate_to is provided, use static window.
            if olddate_to:
                try:
                    timestamp_to = int(olddate_to)
                except (TypeError, ValueError):
                    logging.error("Invalid olddate_to; using current time.")
                    timestamp_to = current_ms
            else:
                # Only olddate_from provided: incremental mode.
                timestamp_to = current_ms
            # Update stored state with the new starting point (as string) for next cycle.
            state.post(str(current_ms))
        else:
            # If backup was already done, revert to rolling window.
            timestamp_from = current_ms - (5 * 60 * 1000)
            timestamp_to = current_ms

    # Prepare headers (include API key)
    headers = {
        "accept": "application/json",
        "api-key": cbs_api_key
    }

    # For each module configuration, build the URL.
    # URL format:
    #   {base_url}?date_from={timestamp_from}&date_to={timestamp_to}&module_type={module_type}&max_hits={max_hits}&q={current_ms}
    for config in module_configs:
        module_type = config["module_type"]
        max_hits = config["max_hits"]
        q_value = current_ms  # Use current time for 'q'

        url = (f"{base_url}?date_from={timestamp_from}"
               f"&date_to={timestamp_to}"
               f"&module_type={module_type}"
               f"&max_hits={max_hits}"
               f"&q={q_value}")
        
        # Append risk parameters only for domain_infringement and subdomain_infringement.
        if module_type in ["domain_infringement", "subdomain_infringement"]:
            url += "&risk_score_min=0&risk_score_max=100"
        
        logging.warning(f"Request URL => {url}")

        success = perform_request(url, headers)
        if success:
            logging.info(f"Data successfully retrieved and posted for module_type: {module_type}")
        else:
            logging.error(f"Failed to retrieve data for module_type: {module_type}")
