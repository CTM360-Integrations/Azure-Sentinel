from azure.storage.fileshare import ShareClient, ShareFileClient
from azure.core.exceptions import ResourceNotFoundError, HttpResponseError

class StateManager:
    def __init__(self, connection_string, share_name='funcstatemarkershare', file_path='funcstatemarkerfile'):
        self.share_cli = ShareClient.from_connection_string(conn_str=connection_string, share_name=share_name)
        self.file_cli = ShareFileClient.from_connection_string(conn_str=connection_string, share_name=share_name, file_path=file_path)

    def post(self, marker_text: str):
        data = marker_text.encode("utf-8")
        try:
            self.file_cli.upload_file(data, overwrite=True)
        except ResourceNotFoundError:
            self.share_cli.create_share()
            self.file_cli.upload_file(data, overwrite=True)
        except HttpResponseError as ex:
            raise ex

    def get(self):
        try:
            return self.file_cli.download_file().readall().decode("utf-8")
        except ResourceNotFoundError:
            return None
